---
permalink: /ABOUT/
---

# About

This is the page for Samuel's journey on his system programming study.

<br>
# More Information

[GitHub]({{ site.urlgithub }})
<br>

# Qapla!
